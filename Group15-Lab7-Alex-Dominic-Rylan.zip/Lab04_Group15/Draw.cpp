#include"Drawable.h"


void draw(Drawable& item) {
	item.draw();
}