#include"BMW.h"

void BMW :: draw()
{
	std::cout << "\nDrawing a BMW: " << std::endl;
	std::cout << "***************** " << std::endl;
	std::cout << "*  *********    *" << std::endl;
	std::cout << "*  *        *   *" << std::endl;
	std::cout << "*  * *******    *" << std::endl;
	std::cout << "*  *        *   *" << std::endl;
	std::cout << "*  *********    *" << std::endl;
	std::cout << "***************** " << std::endl;
}

void BMW :: drive()
{
	std::cout << "\nDriving a BMW" << std::endl;
}