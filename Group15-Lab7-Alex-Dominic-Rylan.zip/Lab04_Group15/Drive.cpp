#include"Vehicle.h"



void drive(Vehicles& car) {
    car.drive();
}
